import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserLoginService } from 'src/app/_services/user-login/user-login.service';

@Component({
  selector: 'app-update-password',
  templateUrl: './update-password.component.html',
  styleUrls: ['./update-password.component.css']
})
export class UpdatePasswordComponent implements OnInit {

  description: string;
  error: string;
  constructor(private service: UserLoginService) { }

  updatePassword(password: NgForm) {
    console.log(password.value);
    this.service.updatePassword(password.value).subscribe(data => {
      console.log(data);
      if (data.statusCode === 402) {
        this.error = data.description;
        setTimeout(() => {
          this.error = null;
        }, 5000);
      } else {
        this.description = data.description;
        setTimeout(() => {
          this.description = null;
        }, 5000);
      }
      password.reset();
    }, err => {
      console.log(err);
    })
  }

  ngOnInit() {
  }

}
