import { Component, OnInit } from '@angular/core';
import { UserLoginService } from 'src/app/_services/user-login/user-login.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-update-email',
  templateUrl: './update-email.component.html',
  styleUrls: ['./update-email.component.css']
})
export class UpdateEmailComponent implements OnInit {

  description: string;
  error: string;
  constructor(private service: UserLoginService) { }

  updateEmail(email: NgForm) {
    console.log(email.value);
    this.service.updateEmail(email.value).subscribe(data => {
      console.log(data);
      if (data.statusCode === 402) {
        this.error = data.description;
        setTimeout(() => {
          this.error = null;
        }, 5000);
      } else {
        this.description = data.description;
        setTimeout(() => {
          this.description = null;
        }, 5000);
      }
      email.reset();
    }, err => {
      console.log(err);
    })
  }

  ngOnInit() {
  }

}
