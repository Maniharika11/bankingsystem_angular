import { Component, OnInit } from '@angular/core';
import { UserLoginService } from 'src/app/_services/user-login/user-login.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-update-mobile',
  templateUrl: './update-mobile.component.html',
  styleUrls: ['./update-mobile.component.css']
})
export class UpdateMobileComponent implements OnInit {

  description: string;
  error: string;
  constructor(private service: UserLoginService) { }

  updateMobile(phone: NgForm) {
    console.log(phone.value);
    this.service.updateMobile(phone.value).subscribe(data => {
      console.log(data);
      if (data.statusCode === 402) {
        this.error = data.description;
        setTimeout(() => {
          this.error = null;
        }, 5000);
      } else {
        this.description = data.description;
        setTimeout(() => {
          this.description = null;
        }, 5000);
      }
      phone.reset();
    }, err => {
      console.log(err);
    })
  }


  ngOnInit() {
  }

}
