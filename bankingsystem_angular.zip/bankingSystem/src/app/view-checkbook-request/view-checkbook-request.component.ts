import { Component, OnInit } from '@angular/core';
import { AllRequest } from './view-checkbook-request';
import { UserLoginService } from '../_services/user-login/user-login.service';

@Component({
  selector: 'app-view-checkbook-request',
  templateUrl: './view-checkbook-request.component.html',
  styleUrls: ['./view-checkbook-request.component.css']
})
export class ViewCheckbookRequestComponent implements OnInit {

  allRequest: AllRequest[];

  constructor(private service: UserLoginService) {
    this.service.viewCheckbookRequest();
  }

  ngOnInit() {
    this.service.viewCheckbookRequest().subscribe(data => {
      this.allRequest = data.checkBookList;
      console.log(data);
    })
  }

}
