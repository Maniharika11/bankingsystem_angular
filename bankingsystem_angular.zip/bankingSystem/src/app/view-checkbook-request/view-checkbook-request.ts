export class AllRequest {
    constructor(
        public serviceId: number,
        public accountId: number,
        public serviceRaisedDate: Date,

    ) { }
}