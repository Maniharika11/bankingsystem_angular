import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewCheckbookRequestComponent } from './view-checkbook-request.component';

describe('ViewCheckbookRequestComponent', () => {
  let component: ViewCheckbookRequestComponent;
  let fixture: ComponentFixture<ViewCheckbookRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ViewCheckbookRequestComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewCheckbookRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
