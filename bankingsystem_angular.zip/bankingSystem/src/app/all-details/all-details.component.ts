import { Component, OnInit } from '@angular/core';
import { UserLoginService } from '../_services/user-login/user-login.service';
import { AllDetails } from './all-details';

@Component({
  selector: 'app-all-details',
  templateUrl: './all-details.component.html',
  styleUrls: ['./all-details.component.css']
})
export class AllDetailsComponent implements OnInit {

  alldetails: AllDetails[];

  constructor(private service: UserLoginService) {
    this.service.getAllDetails();
  }

  ngOnInit() {
    this.service.getAllDetails().subscribe(data => {
      this.alldetails = data.ubean;
      console.log(data);
    })

  }

}
