export class AllDetails {
    constructor(
        public accountId: number,
        public customerName: string,
        public email: string,
        public phone: number,
        public accountType: string,
        public accountBalance: number
    ) { }
}