import { Component, OnInit } from '@angular/core';
import { UserLoginService } from '../_services/user-login/user-login.service';
import { DetailedStatement } from './detailed-statement';

@Component({
  selector: 'app-detailed-statement',
  templateUrl: './detailed-statement.component.html',
  styleUrls: ['./detailed-statement.component.css']
})
export class DetailedStatementComponent implements OnInit {


  detailedStatements: DetailedStatement[];

  constructor(private service: UserLoginService) {
    this.service.getDetailedStatement();
  }
  ngOnInit() {
    this.service.getDetailedStatement().subscribe(data => {
      this.detailedStatements = data.tbean;
      console.log(data);
    })
  };

}
