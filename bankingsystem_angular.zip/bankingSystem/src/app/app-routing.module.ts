import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { MiniStatementComponent } from './mini-statement/mini-statement.component';
import { DetailedStatementComponent } from './detailed-statement/detailed-statement.component';
import { NewAccountComponent } from './new-account/new-account.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { LoginComponent } from './login/login.component';
import { UpdateMobileComponent } from './updateDetails/update-mobile/update-mobile.component';
import { AuthGuard } from './auth.guard';
import { UpdateEmailComponent } from './updateDetails/update-email/update-email.component';
import { UpdatePasswordComponent } from './updateDetails/update-password/update-password.component';
import { AllDetailsComponent } from './all-details/all-details.component';
import { ViewCheckbookRequestComponent } from './view-checkbook-request/view-checkbook-request.component';
import { SendCheckbookRequestComponent } from './send-checkbook-request/send-checkbook-request.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { AboutComponent } from './about/about.component';


const routes: Routes = [
  { path: '', component: HomeComponent},
  { path: 'mini-statement', component : MiniStatementComponent , canActivate : [AuthGuard] , data : {expectedRole : ['user']}},
  { path: 'detailed-statement', component: DetailedStatementComponent,  canActivate : [AuthGuard] , data : {expectedRole : ['Admin']}},
  { path: 'all-details', component: AllDetailsComponent,  canActivate : [AuthGuard] , data : {expectedRole : ['Admin']}},
  { path: 'login', component: LoginComponent},
  { path: 'new-account', component: NewAccountComponent,  canActivate : [AuthGuard] , data : {expectedRole : ['Admin']}},
  { path: 'view-checkbook-request', component: ViewCheckbookRequestComponent,  canActivate : [AuthGuard] , data : {expectedRole : ['Admin']}},
  { path: 'fund-transfer', component: FundTransferComponent ,  canActivate : [AuthGuard] , data : {expectedRole : ['user']}},
  { path: 'update-mobile', component: UpdateMobileComponent,  canActivate : [AuthGuard] , data : {expectedRole : ['user']}},
  { path: 'update-email', component: UpdateEmailComponent,  canActivate : [AuthGuard] , data : {expectedRole : ['user']}},
  { path: 'update-password', component: UpdatePasswordComponent,  canActivate : [AuthGuard] , data : {expectedRole : ['user']}},
  { path: 'send-checkbook-request', component: SendCheckbookRequestComponent,  canActivate : [AuthGuard] , data : {expectedRole : ['user']}},
  { path: 'about', component: AboutComponent},
  { path: '**', component: PageNotFoundComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
