// import { Injectable } from '@angular/core';
// import { HttpClient } from 'selenium-webdriver/http';
// import { Router } from '@angular/router';
// import { Observable } from 'rxjs';

// @Injectable({
//   providedIn: 'root'
// })
// export class BankService {

//   constructor(private http: HttpClient, private router: Router) { }

//   //api = 'http://localhost:8081/users/';


//   // isLoggedIn() {
//   //   const user = JSON.parse(localStorage.getItem('user'));
//   //   if (user && user.registered) {
//   //     return true;
//   //   } else {
//   //     return false;
//   //   }
//   // }

//   // User logout
//   // logout() {
//   //   // Remove the token from local storage
//   //   localStorage.removeItem('token');
//   //   this.router.navigate(['']);
//   // }

//   // register(user): Observable<any> {
//   //   return this.http.post(`${this.api}register`, user);
//   // }

//   // login(credentials): Observable<any> {
//   //   return this.http.post(`${this.api}login`, credentials);
//   // }

//   // loginUser(credentials): Observable<any> {
//   //   return this.http.post(`${this.api}login`, credentials);
//   // }

//   // updateUser(user): Observable<any> {
//   //   return this.http.put<any>(this.api + user.id, user);
//   // }

// }
