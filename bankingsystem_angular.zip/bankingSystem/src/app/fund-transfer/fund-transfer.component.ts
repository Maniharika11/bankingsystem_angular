import { Component, OnInit } from '@angular/core';
import { UserLoginService } from '../_services/user-login/user-login.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {

  description: string;
  error: string;
  constructor(private service: UserLoginService) { }

  transfer(form: NgForm) {
    console.log(form.value);
    this.service.transferFund(form.value).subscribe(res => {
      console.log(res);
      if (res.statusCode === 402) {
        this.error = res.description;
        setTimeout(() => {
          this.error = null;
        }, 5000);
      } else {
        this.description = res.description;
        setTimeout(() => {
          this.description = null;
        }, 5000);
      }
      form.reset();
    }, err => {
      console.log(err);
    });
  }
  ngOnInit() {
  }

}
