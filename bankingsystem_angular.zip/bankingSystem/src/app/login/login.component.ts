import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserLoginService } from '../_services/user-login/user-login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private service: UserLoginService, private router: Router) { }
  description: string;
  error: string;
  login(loginForm: NgForm) {
    console.log(loginForm.value);
    this.service.login(loginForm.value).subscribe(data => {
      console.log(data);

      if (data.statusCode === 402) {
        this.error = data.description;
        setTimeout(() => {
          this.error = null;
        }, 5000);
      } else {
        this.description = data.description;
        setTimeout(() => {
          this.description = null;
        }, 5000);
      }

      console.log(data.userTrackerBean.userType);
      localStorage.setItem('user', JSON.stringify(data));
      this.router.navigateByUrl('/');
      loginForm.reset();

    }, err => {
      console.log(err);
    });
  }

  ngOnInit() {

  }

}
