import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MiniStatement } from 'src/app/mini-statement/mini-statement';
import { User } from 'src/app/new-account';

@Injectable({
  providedIn: 'root'
})
export class UserLoginService {

  constructor(private http: HttpClient) { }

  users: User[] = [];

  ministatements: MiniStatement[] = [];

  backendURL = 'http://localhost:8082';
  createUser(users: User) {
    throw new Error('Method not implemented.');
  }

  isLoggedIn() {
    const userDetails = JSON.parse(localStorage.getItem('user'));
    if (userDetails) {
      return true;
    } else {
      return false;
    }
  }

  login(data) {
    return this.http.post<any>(`${this.backendURL}/login`, data);
  }

  addUser(users) {
    return this.http.post<any>(`${this.backendURL}/addUser`, users);
  }

  getDetailedStatement() {
    return this.http.get<any>(`${this.backendURL}/getTransaction`);
  }

  getAllDetails() {
    return this.http.get<any>(`${this.backendURL}/getAllDetails`);
  }

  viewCheckbookRequest() {
    return this.http.get<any>(`${this.backendURL}/getAllCheckBookRequest`);
  }

  updateMobile(data) {
    return this.http.put<any>(`${this.backendURL}/updateUser`, data);
  }

  updateEmail(data) {
    return this.http.put<any>(`${this.backendURL}/updateUser`, data);
  }

  updatePassword(data) {
    return this.http.put<any>(`${this.backendURL}/updateUser`, data);
  }

  getMiniStatement(mini) {
    return this.http.get<any>(`${this.backendURL}/getAllTransaction?accountId=${mini.accountId}`);
  }

  transferFund(data) {
    return this.http.post<any>(`${this.backendURL}/transaction`, data);
  }

  sendCheckbookRequest(data) {
    return this.http.post<any>(`${this.backendURL}/checkBookRequest`, data);
  }

}
