export class MiniStatement {
    constructor(
        public accountId: number,
        public transactionId: number,
        public tranDescription: string,
        public dateOfTransaction: Date,
        public transactionType: string,
        public tranAmount: number
    ){}
}