import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserLoginService } from '../_services/user-login/user-login.service';
import { MiniStatement } from './mini-statement';

@Component({
  selector: 'app-mini-statement',
  templateUrl: './mini-statement.component.html',
  styleUrls: ['./mini-statement.component.css']
})
export class MiniStatementComponent implements OnInit {

  miniStatements: MiniStatement[];

  constructor(private service: UserLoginService) { }

  getMiniStatement(form: NgForm) {
    console.log(form.value);
    this.service.getMiniStatement(form.value).subscribe(response => {
      console.log(response);
      this.miniStatements = response;
      form.reset();
    }, err => {
      console.log(err);
    });
  }
  ngOnInit() {

  };

}
