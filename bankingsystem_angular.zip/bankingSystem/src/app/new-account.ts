export class User {
    public account_number: number;
    public  account_type: string;
    public address: string;
    public email: string;
    public mobile: number;
    public name: string;
    public pancard : string;
}