import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'
import { HttpClientModule } from '@angular/common/http'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { MiniStatementComponent } from './mini-statement/mini-statement.component';
import { DetailedStatementComponent } from './detailed-statement/detailed-statement.component';
import { NewAccountComponent } from './new-account/new-account.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { LoginComponent } from './login/login.component';
import { UpdateMobileComponent } from './updateDetails/update-mobile/update-mobile.component';
import { UpdatePasswordComponent } from './updateDetails/update-password/update-password.component';
import { UpdateEmailComponent } from './updateDetails/update-email/update-email.component';
import { AllDetailsComponent } from './all-details/all-details.component';
import { SendCheckbookRequestComponent } from './send-checkbook-request/send-checkbook-request.component';
import { ViewCheckbookRequestComponent } from './view-checkbook-request/view-checkbook-request.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { AboutComponent } from './about/about.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    MiniStatementComponent,
    DetailedStatementComponent,
    NewAccountComponent,
    FundTransferComponent,
    LoginComponent,
    UpdateMobileComponent,
    UpdatePasswordComponent,
    UpdateEmailComponent,
    AllDetailsComponent,
    SendCheckbookRequestComponent,
    ViewCheckbookRequestComponent,
    PageNotFoundComponent,
    AboutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
